package com.matchup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchupApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatchupApiApplication.class, args);
	}

}
