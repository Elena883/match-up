package com.matchup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.matchup.model.Plan;
import com.matchup.model.Usuario;
import com.matchup.model.UsuarioPlan;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UsuarioPlanRepository;
import com.matchup.repository.UsuarioRepository;

@Service
public class UsuarioPlanService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private PlanRepository planRepository;

	@Autowired
	private UsuarioPlanRepository usuarioPlanRepository;
	


	public List<UsuarioPlan> obtenerParticipantesPorPlan(Long idPlan) {
		return usuarioPlanRepository.findByPlanId(idPlan);
	}

	public boolean existeRelacion(Long idUsuario, Long idPlan) {
		return usuarioPlanRepository.existsByUsuarioIdAndPlanId(idUsuario, idPlan);
	}

	public void unirseAPlan(Long idUsuario, Long idPlan) {

		Usuario usuario = usuarioRepository.findById(idUsuario)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		Plan plan = planRepository.findById(idPlan).orElseThrow(() -> new RuntimeException("Plan no encontrado"));

		UsuarioPlan usuarioPlan = new UsuarioPlan();
		usuarioPlan.setUsuario(usuario);
		usuarioPlan.setPlan(plan);

		usuarioPlan.setRol("PARTICIPANTE");
		usuarioPlan.setEstado("ACTIVO");
		usuarioPlan.setFechaUnion(java.time.LocalDateTime.now());

		usuarioPlanRepository.save(usuarioPlan);
		
		
	}
	
	public void salirDelPlan(Long idUsuario, Long idPlan) {

	    usuarioPlanRepository.salirDelPlan(idUsuario, idPlan);
	}
}