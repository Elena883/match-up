package com.matchup.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.matchup.model.Grupo;
import com.matchup.model.Mensaje;
import com.matchup.model.Usuario;
import com.matchup.repository.GrupoRepository;
import com.matchup.repository.MensajeRepository;
import com.matchup.repository.UsuarioGrupoRepository;
import com.matchup.repository.UsuarioRepository;

@Service
public class MensajeService {

	@Autowired
	private MensajeRepository mensajeRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private UsuarioGrupoRepository usuarioGrupoRepository;

	@Autowired
	private GrupoRepository grupoRepository;



	public Mensaje enviarMensaje(Long idUsuario, Long idGrupo, String contenido) {

		Usuario usuario = usuarioRepository.findById(idUsuario)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		Grupo grupo = grupoRepository.findById(idGrupo).orElseThrow(() -> new RuntimeException("Grupo no encontrado"));

	

		boolean pertenece = usuarioGrupoRepository.existsByGrupoIdAndUsuarioId(idGrupo, idUsuario);

		if (!pertenece) {

			throw new RuntimeException("No perteneces al grupo");
		}

	

		Mensaje mensaje = new Mensaje();

		mensaje.setContenido(contenido);

		mensaje.setFechaEnvio(LocalDateTime.now());

		mensaje.setUsuario(usuario);

		mensaje.setGrupo(grupo);

		return mensajeRepository.save(mensaje);
	}

	public boolean tieneAccesoChat(Long idGrupo, Long idUsuario) {

		return usuarioGrupoRepository.existsByGrupoIdAndUsuarioId(idGrupo, idUsuario);
	}

	

	public List<Mensaje> obtenerMensajesGrupo(Long idGrupo) {

		return mensajeRepository.findByGrupoIdOrderByIdAsc(idGrupo);
	}

	

	public List<Mensaje> obtenerMensajesNuevos(Long idGrupo, Long ultimoId) {

		return mensajeRepository.findByGrupoIdAndIdGreaterThanOrderByIdAsc(idGrupo, ultimoId);
	}

	public Mensaje obtenerUltimoMensaje(Long idGrupo) {

		return mensajeRepository.findTopByGrupoIdOrderByFechaEnvioDesc(idGrupo);
	}
}