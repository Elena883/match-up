package com.matchup.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import com.matchup.dto.GrupoDTO;
import com.matchup.dto.MensajeDTO;
import com.matchup.dto.MiembroGrupoDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Grupo;
import com.matchup.model.Plan;
import com.matchup.model.Usuario;
import com.matchup.model.UsuarioGrupo;
import com.matchup.repository.CategoriaRepository;
import com.matchup.repository.GrupoRepository;
import com.matchup.repository.MensajeRepository;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UsuarioGrupoRepository;
import com.matchup.repository.UsuarioRepository;

@Service
public class GrupoService {

	@Autowired
	private GrupoRepository grupoRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private PlanRepository planRepository;

	@Autowired
	private UsuarioGrupoRepository grupoUsuarioRepository;

	@Autowired
	private CategoriaRepository categoriaRepository;
	
	@Autowired
	private MensajeRepository mensajeRepository;

	public GrupoDTO crearGrupo(Grupo grupo, Long categoriaId, Long idUsuario, Long idPlan, MultipartFile foto) {

		Usuario creador = usuarioRepository.findById(idUsuario).orElseThrow();

		Categoria categoria = categoriaRepository.findById(categoriaId)
				.orElseThrow(() -> new RuntimeException("Categoría no encontrada"));

		grupo.setCategoria(categoria);
		grupo.setCreador(creador);

		grupo.setFecha_creacion(LocalDateTime.now());

	

		Plan plan = null;

		if (idPlan != null) {

			plan = planRepository.findById(idPlan).orElseThrow();

			grupo.setPlan(plan);
		}


		if (foto != null && !foto.isEmpty()) {

			try {

				String nombreArchivo = System.currentTimeMillis() + "_" + foto.getOriginalFilename();

				String ruta = "C:/matchup/fotos_grupo/";

				File destino = new File(ruta + nombreArchivo);

				foto.transferTo(destino);

				grupo.setImagen(nombreArchivo);

			} catch (IOException e) {

				e.printStackTrace();
			}
		}

		Grupo grupoGuardado = grupoRepository.save(grupo);

	

		UsuarioGrupo grupoUsuario = new UsuarioGrupo();

		grupoUsuario.setGrupo(grupoGuardado);

		grupoUsuario.setUsuario(creador);

		grupoUsuario.setRol("CREADOR");

		grupoUsuario.setFecha_union(LocalDateTime.now());

		grupoUsuarioRepository.save(grupoUsuario);

		return new GrupoDTO(

				grupoGuardado.getId(),

				grupoGuardado.getNombre(),

				grupoGuardado.getDescripcion(),

				creador.getNombreUsuario(),

				plan != null ? plan.getTitulo() : null);
	}

	public String unirseGrupo(Long idGrupo, Long idUsuario) {

		Optional<Grupo> grupoOpt = grupoRepository.findById(idGrupo);
		Optional<Usuario> usuarioOpt = usuarioRepository.findById(idUsuario);

		if (grupoOpt.isEmpty() || usuarioOpt.isEmpty()) {

			return "Grupo o usuario no encontrado";
		}

		Grupo grupo = grupoOpt.get();
		Usuario usuario = usuarioOpt.get();

	
		boolean yaExiste = grupoUsuarioRepository.existsByGrupoIdAndUsuarioId(idGrupo, idUsuario);

		if (yaExiste) {

			return "Ya estás en el grupo";
		}

	
		long total = grupoUsuarioRepository.countByGrupoId(idGrupo);

		if (total >= grupo.getNum_max_miembros()) {

			return "El grupo está lleno";
		}

	

		UsuarioGrupo usuarioGrupo = new UsuarioGrupo();

		usuarioGrupo.setGrupo(grupo);

		usuarioGrupo.setUsuario(usuario);

		usuarioGrupo.setRol("MIEMBRO");

		usuarioGrupo.setFecha_union(LocalDateTime.now());

		grupoUsuarioRepository.save(usuarioGrupo);

		return "Te has unido al grupo";
	}

	public List<MiembroGrupoDTO> obtenerMiembros(Long idGrupo) {

		List<UsuarioGrupo> relaciones = grupoUsuarioRepository.findByGrupoId(idGrupo);

		return relaciones.stream().map(relacion -> {

			Usuario usuario = relacion.getUsuario();

			MiembroGrupoDTO dto = new MiembroGrupoDTO();

			dto.setIdUsuario(usuario.getId());

			dto.setNombreUsuario(usuario.getNombreUsuario());

			dto.setFotoPerfil(usuario.getFotoPerfil());

			return dto;

		}).toList();
	}

	public String salirGrupo(Long idGrupo, Long idUsuario) {

		boolean pertenece = grupoUsuarioRepository.existsByGrupoIdAndUsuarioId(idGrupo, idUsuario);

		if (!pertenece) {
			return "El usuario no pertenece al grupo";
		}

		Grupo grupo = grupoRepository.findById(idGrupo).orElseThrow();

		if (grupo.getCreador().getId().equals(idUsuario)) {
			return "El creador no puede salir del grupo";
		}

		grupoUsuarioRepository.deleteByGrupoIdAndUsuarioId(idGrupo, idUsuario);

		return "Has salido del grupo";
	}

	@Transactional
	public String eliminarGrupo(Long idGrupo, Long idUsuario) {

		Grupo grupo = grupoRepository.findById(idGrupo).orElseThrow();

		if (!grupo.getCreador().getId().equals(idUsuario)) {
			return "Solo el creador puede eliminar el grupo";
		}

		grupoUsuarioRepository.deleteByGrupoId(idGrupo);
		
		mensajeRepository.deleteByGrupoId(idGrupo);

		grupoRepository.deleteById(idGrupo);

		return "Grupo eliminado correctamente";
	}

	public Grupo obtenerGrupoPorPlan(Long idPlan) {

		return grupoRepository.findByPlanId(idPlan).orElse(null);
	}

	public Optional<Grupo> obtenerPorId(Long id) {

		return grupoRepository.findById(id);
	}

	public Grupo editarGrupo(

			Long idGrupo, String nombre, String descripcion, Long categoriaId, Integer numMaxMiembros,
			MultipartFile imagen

	) throws Exception {

		Grupo grupo = grupoRepository.findById(idGrupo).orElseThrow(() -> new RuntimeException("Grupo no encontrado"));
		Categoria categoria = categoriaRepository.findById(categoriaId).orElseThrow();
		grupo.setNombre(nombre);
		grupo.setDescripcion(descripcion);
		grupo.setCategoria(categoria);
		grupo.setNum_max_miembros(numMaxMiembros);

		if (imagen != null && !imagen.isEmpty()) {

			String ruta = "C:/matchup/fotos_grupo/";

			File carpeta = new File(ruta);

			if (!carpeta.exists()) {
				carpeta.mkdirs();
			}

			String nombreArchivo = System.currentTimeMillis() + "_" + imagen.getOriginalFilename();

			File destino = new File(ruta + nombreArchivo);

			imagen.transferTo(destino);

			grupo.setImagen(nombreArchivo);
		}

		return grupoRepository.save(grupo);
	}

	public List<Grupo> filtrarGrupos(String busqueda, String categoria) {

		boolean tieneBusqueda = busqueda != null && !busqueda.isBlank();

		boolean tieneCategoria = categoria != null && !categoria.isBlank();

		

		if (tieneBusqueda && tieneCategoria) {

			return grupoRepository.findByNombreContainingIgnoreCaseAndCategoriaNombreIgnoreCase(busqueda, categoria);
		}

	

		if (tieneBusqueda) {

			return grupoRepository.findByNombreContainingIgnoreCase(busqueda);
		}

	
		if (tieneCategoria) {

			return grupoRepository.findByCategoriaNombreIgnoreCase(categoria);
		}

	

		return grupoRepository.findAll();
	}
}