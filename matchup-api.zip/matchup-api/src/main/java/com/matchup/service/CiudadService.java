package com.matchup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.matchup.model.Ciudad;
import com.matchup.repository.CiudadRepository;

@Service
public class CiudadService {

    @Autowired
    private CiudadRepository ciudadRepository;

    public List<Ciudad> obtenerTodas() {

        return ciudadRepository.findAllByOrderByNombreAsc();
    }

    public CiudadService(CiudadRepository ciudadRepository) {
        this.ciudadRepository = ciudadRepository;
    }

    public List<Ciudad> obtenerPorPais(Long paisId) {
        return ciudadRepository.findByPaisId(paisId);
    }
}