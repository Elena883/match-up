package com.matchup.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.matchup.model.PreferenciasUsuario;
import com.matchup.repository.CategoriaRepository;
import com.matchup.repository.CiudadRepository;
import com.matchup.repository.GrupoRepository;
import com.matchup.repository.MensajeRepository;
import com.matchup.dto.UsuarioRecomendadoDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Ciudad;
import com.matchup.model.Grupo;
import com.matchup.model.Mensaje;
import com.matchup.model.Plan;
import com.matchup.repository.PreferenciasUsuarioRepository;
import com.matchup.repository.UsuarioCategoriaRepository;
import com.matchup.repository.UsuarioGrupoRepository;
import com.matchup.dto.ActividadUsuarioDTO;
import com.matchup.model.Usuario;
import com.matchup.model.UsuarioCategoria;
import com.matchup.model.UsuarioPlan;
import com.matchup.repository.CategoriaRepository;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UsuarioPlanRepository;
import com.matchup.repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioCategoriaRepository usuarioCategoriaRepository;

	@Autowired
	private PreferenciasUsuarioRepository preferenciasUsuarioRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private PlanRepository planRepository;

	@Autowired
	private CiudadRepository ciudadRepository;

	@Autowired
	private UsuarioPlanRepository usuarioPlanRepository;

	@Autowired
	private CategoriaRepository categoriaRepository;

	@Autowired
	private UsuarioGrupoRepository usuarioGrupoRepository;

	@Autowired
	private MensajeRepository mensajeRepository;

	@Autowired
	private GrupoRepository grupoRepository;

	public Usuario obtenerUsuarioPorId(Long id) {

		return usuarioRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
	}

	public List<Plan> obtenerPlanesUsuario(Long idUsuario) {

		List<UsuarioPlan> relaciones = usuarioPlanRepository.findByUsuarioId(idUsuario);

		return relaciones.stream().map(UsuarioPlan::getPlan).toList();
	}

	@Transactional
	public Usuario actualizarPerfil(

			Long id,

			String nombreUsuario, String nombre, String fechaNacimiento, String bio, Long idCiudad,

			String disponibilidad, Integer distancia, String ritmo, String tipo_plan,

			String categoriasIds,

			MultipartFile fotoPerfil

	) throws Exception {

		Usuario usuario = usuarioRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		usuario.setNombreUsuario(nombreUsuario);
		usuario.setNombre(nombre);

		if (fechaNacimiento != null && !fechaNacimiento.isEmpty()) {

			usuario.setFechaNacimiento(LocalDate.parse(fechaNacimiento));
		}

		Ciudad ciudad = ciudadRepository.findById(idCiudad).orElseThrow();

		usuario.setBio(bio);
		usuario.setCiudad(ciudad);

		if (fotoPerfil != null && !fotoPerfil.isEmpty()) {

			String rutaCarpeta = "C:/matchup/fotos_perfil";

			File carpeta = new File(rutaCarpeta);

			if (!carpeta.exists()) {

				carpeta.mkdirs();
			}

			String nombreArchivo = System.currentTimeMillis() + "_" + fotoPerfil.getOriginalFilename();

			File archivoDestino = new File(rutaCarpeta + "/" + nombreArchivo);

			fotoPerfil.transferTo(archivoDestino);

			usuario.setFotoPerfil(nombreArchivo);
		}

		PreferenciasUsuario pref = usuario.getPreferencias();

		if (pref == null) {

			pref = new PreferenciasUsuario();

			pref.setUsuario(usuario);
		}

		pref.setDisponibilidad(disponibilidad);
		pref.setDistancia(distancia);
		pref.setRitmo(ritmo);
		pref.setTipo_plan(tipo_plan);

		preferenciasUsuarioRepository.save(pref);

		usuarioCategoriaRepository.deleteByUsuarioId(id);

		ObjectMapper mapper = new ObjectMapper();

		List<Long> ids = mapper.readValue(categoriasIds, new TypeReference<List<Long>>() {
		});

		List<UsuarioCategoria> nuevasCategorias = new ArrayList<>();

		for (Long idCategoria : ids) {

			Categoria categoria = categoriaRepository.findById(idCategoria).orElseThrow();

			UsuarioCategoria uc = new UsuarioCategoria();

			uc.setUsuario(usuario);
			uc.setCategoria(categoria);

			nuevasCategorias.add(uc);
		}

		usuarioCategoriaRepository.saveAll(nuevasCategorias);

		return usuarioRepository.save(usuario);
	}

	public UsuarioRecomendadoDTO obtenerPerfilRecomendado(Long idUsuario) {

		Usuario usuarioActual = usuarioRepository.findById(idUsuario).orElseThrow();

		List<Usuario> usuarios = usuarioRepository.findAll();

		Usuario mejorUsuario = null;

		int maxCoincidencias = -1;

		for (Usuario usuario : usuarios) {

			if (usuario.getId().equals(idUsuario)) {
				continue;
			}

			int coincidencias = 0;

			for (UsuarioCategoria c1 : usuarioActual.getCategorias()) {

				for (UsuarioCategoria c2 : usuario.getCategorias()) {

					if (c1.getCategoria().getNombre().equalsIgnoreCase(c2.getCategoria().getNombre())) {
						coincidencias++;
					}
				}
			}

			if (usuarioActual.getCiudad() != null && usuario.getCiudad() != null
					&& usuarioActual.getCiudad().getNombre().equalsIgnoreCase(usuario.getCiudad().getNombre())) {

				coincidencias += 2;
			}

			if (coincidencias > maxCoincidencias) {

				maxCoincidencias = coincidencias;
				mejorUsuario = usuario;
			}
		}

		if (mejorUsuario == null) {
			return null;
		}

		UsuarioRecomendadoDTO dto = new UsuarioRecomendadoDTO();

		dto.setId(mejorUsuario.getId());
		dto.setNombre(mejorUsuario.getNombre());
		LocalDate fechaNacimiento = mejorUsuario.getFechaNacimiento();

		int edad = Period.between(fechaNacimiento, LocalDate.now()).getYears();

		dto.setEdad(edad);
		dto.setBio(mejorUsuario.getBio());
		dto.setFotoPerfil(mejorUsuario.getFotoPerfil());

		dto.setCoincidencias(maxCoincidencias);

		return dto;
	}

	public ActividadUsuarioDTO obtenerActividadUsuario(Long idUsuario) {

		ActividadUsuarioDTO dto = new ActividadUsuarioDTO();

		int planesCreados = planRepository.findByCreadorId(idUsuario).size();

		dto.setPlanesCreados(planesCreados);

		int planesUnidos = usuarioPlanRepository.findByUsuarioId(idUsuario).size();

		dto.setPlanesUnidos(planesUnidos);

		int personasConocidas = 0;

		List<UsuarioPlan> relaciones = usuarioPlanRepository.findByUsuarioId(idUsuario);

		for (UsuarioPlan up : relaciones) {

			List<UsuarioPlan> participantes = usuarioPlanRepository.findByPlanId(up.getPlan().getId());

			personasConocidas += participantes.size() - 1;
		}

		dto.setPersonasConocidas(Math.max(personasConocidas, 0));

		Usuario usuario = usuarioRepository.findById(idUsuario).orElse(null);

		if (usuario != null && usuario.getCategorias() != null && !usuario.getCategorias().isEmpty()) {

			dto.setCategoriaFavorita(usuario.getCategorias().get(0).getCategoria().getNombre());

		} else {

			dto.setCategoriaFavorita("Sin categoría");
		}

		return dto;
	}

	@Transactional
	public void eliminarUsuario(Long idUsuario) {

		Usuario usuario = usuarioRepository.findById(idUsuario)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		Usuario deletedUser = usuarioRepository.findByNombreUsuario("deleted_account")
				.orElseThrow(() -> new RuntimeException("Usuario deleted_account no existe"));

		List<Mensaje> mensajes = mensajeRepository.findByUsuarioId(idUsuario);

		for (Mensaje mensaje : mensajes) {

			mensaje.setUsuario(deletedUser);
		}

		mensajeRepository.saveAll(mensajes);

		List<Plan> planesCreados = planRepository.findByCreadorId(idUsuario);

		for (Plan plan : planesCreados) {

			List<Grupo> grupos = grupoRepository.findAllByPlanId(plan.getId());

			for (Grupo grupo : grupos) {

				mensajeRepository.deleteByGrupoId(grupo.getId());
			}

			grupoRepository.deleteAll(grupos);

			planRepository.delete(plan);
		}

		usuarioCategoriaRepository.deleteByUsuarioId(idUsuario);

		usuarioPlanRepository.deleteByUsuarioId(idUsuario);

		usuarioGrupoRepository.deleteByUsuarioId(idUsuario);

		preferenciasUsuarioRepository.deleteByUsuarioId(idUsuario);

		usuarioRepository.delete(usuario);
	}

	public List<UsuarioRecomendadoDTO> obtenerUsuariosRecomendados(Long idUsuario) {

		Usuario usuarioActual = usuarioRepository.findById(idUsuario)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		List<String> categoriasUsuario = usuarioActual.getCategorias().stream()
				.map(uc -> uc.getCategoria().getNombre().toLowerCase()).toList();

		List<Usuario> todosUsuarios = usuarioRepository.findAll();

		List<UsuarioRecomendadoDTO> recomendados = new ArrayList<>();

		for (Usuario usuario : todosUsuarios) {

			if (usuario.getId().equals(idUsuario)) {
				continue;
			}

			List<String> categoriasOtro = usuario.getCategorias().stream().map(uc -> uc.getCategoria().getNombre())
					.toList();

			int coincidencias = 0;

			for (String categoria : categoriasOtro) {

				if (categoriasUsuario.contains(categoria.toLowerCase())) {
					coincidencias++;
				}
			}

			if (coincidencias > 0) {

				UsuarioRecomendadoDTO dto = new UsuarioRecomendadoDTO();

				dto.setId(usuario.getId());

				dto.setNombre(usuario.getNombre());

				dto.setBio(usuario.getBio());

				dto.setFotoPerfil(usuario.getFotoPerfil());

				dto.setIntereses(categoriasOtro);

				dto.setCoincidencias(coincidencias);

				if (usuario.getFechaNacimiento() != null) {

					int edad = Period.between(usuario.getFechaNacimiento(), LocalDate.now()).getYears();

					dto.setEdad(edad);
				}

				recomendados.add(dto);
			}
		}

		recomendados.sort((a, b) -> b.getCoincidencias().compareTo(a.getCoincidencias()));

		return recomendados.stream().limit(6).toList();
	}

}
