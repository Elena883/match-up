package com.matchup.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.matchup.model.Pais;
import com.matchup.repository.PaisRepository;

@Service
public class PaisService {
	
	
	private final PaisRepository paisRepository;

    public PaisService(PaisRepository paisRepository) {
        this.paisRepository = paisRepository;
    }

    public List<Pais> obtenerTodos() {
        return paisRepository.findAll();
    }
	

}
