package com.matchup.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import java.time.LocalDateTime;
import org.springframework.web.multipart.MultipartFile;

import com.matchup.dto.CrearPlanDTO;
import com.matchup.dto.PlanDTO;
import com.matchup.dto.PlanRecomendadoDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Ciudad;
import com.matchup.model.Grupo;
import com.matchup.model.Pais;
import com.matchup.model.Plan;
import com.matchup.model.Ubicacion;
import com.matchup.model.Usuario;
import com.matchup.model.UsuarioPlan;
import com.matchup.repository.CategoriaRepository;
import com.matchup.repository.CiudadRepository;
import com.matchup.repository.GrupoRepository;
import com.matchup.repository.PaisRepository;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UbicacionRepository;
import com.matchup.repository.UsuarioPlanRepository;
import com.matchup.repository.UsuarioRepository;

@Service
public class PlanService {

	@Autowired
	private PlanRepository planRepository;
	@Autowired
	private UsuarioPlanRepository usuarioPlanRepository;

	@Autowired
	private CategoriaRepository categoriaRepository;

	@Autowired
	private UbicacionRepository ubicacionRepository;

	@Autowired
	private CiudadRepository ciudadRepository;

	@Autowired
	private PaisRepository paisRepository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private GrupoRepository grupoRepository;

	public List<Plan> obtenerPlanesPorUsuario(Long idUsuario) {
		return planRepository.findByCreadorId(idUsuario);
	}

	public List<Plan> obtenerPlanesCreador(Long id) {

		return planRepository.findByCreadorId(id);
	}

	public PlanDTO obtenerPlanPopular() {

		List<Plan> planes = planRepository.findAll();

		if (planes.isEmpty()) {
			return null;
		}

		Plan mejorPlan = planes.stream().max(Comparator.comparingInt(p -> p.getNum_max_participantes())).orElse(null);

		if (mejorPlan == null) {
			return null;
		}

		PlanDTO dto = new PlanDTO();

		dto.setIdPlan(mejorPlan.getId());
		dto.setTitulo(mejorPlan.getTitulo());
		dto.setDescripcion(mejorPlan.getDescripcion());
		dto.setImagen(mejorPlan.getImagen());

		dto.setUbicacion(mejorPlan.getUbicacion());

		dto.setParticipantes(mejorPlan.getNum_max_participantes());

		return dto;
	}

	public PlanDTO obtenerRecomendacionDia(Long idUsuario) {

		Usuario usuario = usuarioRepository.findById(idUsuario).orElse(null);

		if (usuario == null) {
			return null;
		}

		List<Plan> planes = planRepository.findAll();

		Plan mejorPlan = null;

		int maxCoincidencias = -1;

		for (Plan plan : planes) {

			int coincidencias = 0;

			if (plan.getCategoria() != null) {

				if (usuario.getCategorias().contains(plan.getCategoria())) {
					coincidencias++;
				}
			}

			if (coincidencias > maxCoincidencias) {

				maxCoincidencias = coincidencias;
				mejorPlan = plan;
			}
		}

		if (mejorPlan == null) {
			return null;
		}

		PlanDTO dto = new PlanDTO();

		dto.setIdPlan(mejorPlan.getId());
		dto.setTitulo(mejorPlan.getTitulo());
		dto.setDescripcion(mejorPlan.getDescripcion());
		dto.setImagen(mejorPlan.getImagen());
		dto.setUbicacion(mejorPlan.getUbicacion());

		return dto;
	}

	public List<Plan> obtenerPlanesActivos(Long idUsuario) {

		return usuarioPlanRepository.obtenerPlanesActivos(idUsuario);
	}

	public List<Plan> obtenerHistorial(Long idUsuario) {

		return usuarioPlanRepository.obtenerHistorial(idUsuario);
	}

	public List<Plan> filtrarPlanes(String busqueda, String categoria) {

		return planRepository.filtrarPlanes(busqueda, categoria);
	}

	public List<PlanRecomendadoDTO> obtenerPlanesRecomendados(Long idUsuario) {

		Usuario usuario = usuarioRepository.findById(idUsuario).orElseThrow();

		List<String> interesesUsuario = usuario.getCategorias().stream()
				.map(c -> c.getCategoria().getNombre().toLowerCase()).toList();

		List<Plan> todosPlanes = planRepository.findAll();

		List<PlanRecomendadoDTO> recomendados = new ArrayList<>();

		for (Plan plan : todosPlanes) {

			if (plan.getCreador().getId().equals(idUsuario)) {
				continue;
			}

			if (plan.getCategoria() == null) {
				continue;
			}

			boolean coincide = interesesUsuario.contains(plan.getCategoria().getNombre().toLowerCase());

			if (coincide) {

				PlanRecomendadoDTO dto = new PlanRecomendadoDTO();

				dto.setIdPlan(plan.getId());
				dto.setTitulo(plan.getTitulo());
				dto.setDescripcion(plan.getDescripcion());
				dto.setImagen(plan.getImagen());
				dto.setCategoria(plan.getCategoria());

				recomendados.add(dto);
			}
		}

		return recomendados.stream().limit(2).toList();
	}

	public Plan obtenerUltimoPlanUsuario(Long idUsuario) {

		List<UsuarioPlan> lista = usuarioPlanRepository.findByUsuarioId(idUsuario);

		if (lista.isEmpty()) {
			return null;
		}

		UsuarioPlan ultimo = lista.get(lista.size() - 1);

		return ultimo.getPlan();
	}

	public Plan obtenerPlanPorId(Long idPlan) {

		return planRepository.findById(idPlan).orElseThrow(() -> new RuntimeException("Plan no encontrado"));
	}

	@Transactional
	public void eliminarPlanPorId(Long idPlan) {

		Plan plan = planRepository.findById(idPlan).orElseThrow(() -> new RuntimeException("Plan no encontrado"));

	

		List<Grupo> grupos = grupoRepository.findAllByPlanId(idPlan);

		for (Grupo grupo : grupos) {

			grupo.setPlan(null);
		}

		grupoRepository.saveAll(grupos);

		usuarioPlanRepository.deleteByPlanId(idPlan);


		planRepository.delete(plan);
	}

	public Plan editarPlan(

			Long id, String titulo, String descripcion, Long idPais, Long idCiudad, String direccion, Long idCategoria,
			Integer numMaxParticipantes, String fechaPlan, MultipartFile imagen

	) {

		Plan plan = planRepository.findById(id).orElseThrow(() -> new RuntimeException("Plan no encontrado"));

		List<UsuarioPlan> participantes = usuarioPlanRepository.findByPlanId(id);

		long activos = participantes.stream().filter(up -> up.getEstado().equals("ACTIVO")).count();

		plan.setTitulo(titulo);

		plan.setDescripcion(descripcion);

		Pais pais = paisRepository.findById(idPais).orElseThrow();

		Ciudad ciudad = ciudadRepository.findById(idCiudad).orElseThrow();

		Ubicacion ubicacion = plan.getUbicacion();

		ubicacion.setPais(pais);
		ubicacion.setCiudad(ciudad);
		ubicacion.setDireccion(direccion);

		if (activos <= 1) {

			plan.setUbicacion(ubicacion);

			LocalDateTime fecha = LocalDateTime.parse(fechaPlan);

			plan.setFecha_plan(fecha);
		}

		Categoria categoria = new Categoria();
		categoria = categoriaRepository.findById(idCategoria).orElseThrow();

		plan.setCategoria(categoria);

		plan.setNum_max_participantes(numMaxParticipantes);

		try {

			if (imagen != null && !imagen.isEmpty()) {

				String nombreArchivo = System.currentTimeMillis() + "_" + imagen.getOriginalFilename();

				Path ruta = Paths.get("C:/matchup/fotos_plan");

				if (!Files.exists(ruta)) {
					Files.createDirectories(ruta);
				}

				Files.copy(imagen.getInputStream(), ruta.resolve(nombreArchivo), StandardCopyOption.REPLACE_EXISTING);

				plan.setImagen(nombreArchivo);
			}

		} catch (Exception e) {

			throw new RuntimeException("Error guardando imagen");
		}

		return planRepository.save(plan);
	}

	public Plan crearPlan(CrearPlanDTO request, Long idUsuario) {

		Usuario creador = usuarioRepository.findById(idUsuario)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

		Plan plan = new Plan();

		System.out.println("CategoriaId: " + request.getCategoriaId());
		System.out.println("PaisId: " + request.getPaisId());
		System.out.println("CiudadId: " + request.getCiudadId());
		System.out.println("UsuarioId: " + request);

		Categoria categoria = categoriaRepository.findById(request.getCategoriaId()).orElseThrow();

		Ciudad ciudad = ciudadRepository.findById(request.getCiudadId()).orElseThrow();

		Pais pais = paisRepository.findById(request.getPaisId()).orElseThrow();

		Ubicacion ubi = new Ubicacion();
		ubi.setPais(pais);
		ubi.setCiudad(ciudad);
		ubi.setDireccion(request.getDireccion());
		ubi = ubicacionRepository.save(ubi);

		plan.setTitulo(request.getTitulo());
		plan.setDescripcion(request.getDescripcion());
		plan.setNum_max_participantes(request.getNumMaxParticipantes());
		plan.setCategoria(categoria);

		LocalDateTime fechaPlan = LocalDateTime.parse(request.getFecha() + "T" + request.getHora());

		plan.setFecha_plan(fechaPlan);

		plan.setEstado("ACTIVO");
		plan.setFecha_creacion(LocalDateTime.now());

		plan.setUbicacion(ubi);
		plan.setDuracion(request.getDuracion());
		plan.setPrivacidad(request.getPrivacidad());
		plan.setPerfilBuscado(request.getPerfilBuscado());
		plan.setImagen(request.getImagen());

		plan.setCreador(creador);

		Plan planGuardado = planRepository.save(plan);

		UsuarioPlan up = new UsuarioPlan();

		up.setUsuario(creador);
		up.setPlan(planGuardado);

		up.setRol("CREADOR");
		up.setEstado("ACTIVO");
		up.setFechaUnion(LocalDateTime.now());

		usuarioPlanRepository.save(up);

		return planGuardado;
	}

	public List<Plan> obtenerPlanesGrupo(Long idGrupo) {

		return planRepository.findByGrupoId(idGrupo);
	}
}