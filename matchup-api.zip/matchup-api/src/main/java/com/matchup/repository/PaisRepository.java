package com.matchup.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.matchup.model.Pais;

@Repository
public interface PaisRepository extends JpaRepository<Pais, Long> {

}
