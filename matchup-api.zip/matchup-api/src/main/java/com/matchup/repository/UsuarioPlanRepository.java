package com.matchup.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.matchup.model.Plan;
import com.matchup.model.UsuarioPlan;

@Repository
public interface UsuarioPlanRepository extends JpaRepository<UsuarioPlan, Long> {
	@Transactional
	void deleteByUsuarioId(Long idUsuario);

	@Query("SELECT up FROM UsuarioPlan up WHERE up.plan.id = :idPlan")
	List<UsuarioPlan> findByPlanId(Long idPlan);

	boolean existsByUsuarioIdAndPlanId(Long idUsuario, Long idPlan);

	List<UsuarioPlan> findByUsuarioId(Long idUsuario);

	@Query("""
			SELECT up
			FROM UsuarioPlan up
			WHERE up.usuario.id = :idUsuario
			ORDER BY up.plan.fecha_plan DESC
			""")
	List<UsuarioPlan> obtenerPlanesUsuario(Long idUsuario);

	@Query("""
			    SELECT up.plan
			    FROM UsuarioPlan up
			    WHERE up.plan.fecha_plan >= CURRENT_TIMESTAMP
			    GROUP BY up.plan
			    ORDER BY COUNT(up.usuario.id) DESC
			""")
	List<Plan> obtenerPlanesPopulares();

	@Query("""
			    SELECT up.plan
			    FROM UsuarioPlan up
			    WHERE up.usuario.id = :idUsuario
			    AND up.plan.fecha_plan >= CURRENT_TIMESTAMP
			    ORDER BY up.plan.fecha_plan ASC
			""")
	List<Plan> obtenerPlanesActivos(Long idUsuario);

	@Query("""
			    SELECT up.plan
			    FROM UsuarioPlan up
			    WHERE up.usuario.id = :idUsuario
			    AND up.plan.fecha_plan < CURRENT_TIMESTAMP
			    ORDER BY up.plan.fecha_plan DESC
			""")
	List<Plan> obtenerHistorial(Long idUsuario);

	@Transactional
	@Modifying
	@Query("DELETE FROM UsuarioPlan up WHERE up.plan.id = :idPlan")
	void deleteByPlanId(Long idPlan);

	@Transactional
	@Modifying
	@Query("""
			    DELETE FROM UsuarioPlan up
			    WHERE up.usuario.id = :idUsuario
			    AND up.plan.id = :idPlan
			""")
	void salirDelPlan(Long idUsuario, Long idPlan);
	
	

}
