package com.matchup.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import com.matchup.model.UsuarioGrupo;

@Repository
public interface UsuarioGrupoRepository extends JpaRepository<UsuarioGrupo, Long> {

	List<UsuarioGrupo> findByGrupoId(Long idGrupo);

	boolean existsByGrupoIdAndUsuarioId(Long idGrupo, Long idUsuario);

	@Transactional
	@Modifying
	void deleteByGrupoIdAndUsuarioId(Long idGrupo, Long idUsuario);

	@Transactional
	@Modifying
	void deleteByGrupoId(Long idGrupo);

	List<UsuarioGrupo> findByUsuarioId(Long idUsuario);

	long countByGrupoId(Long grupoId);

	void deleteByUsuarioId(Long idUsuario);

	int countByUsuarioId(Long id);
}
