package com.matchup.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.matchup.model.Mensaje;
import com.matchup.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

	boolean existsByEmail(String email);

	@Transactional
	void deleteById(Long id);

	Optional<Usuario> findByEmailOrNombreUsuario(String email, String nombreUsuario);
	
	Optional<Usuario> findByNombreUsuario(String nombreUsuario);
}