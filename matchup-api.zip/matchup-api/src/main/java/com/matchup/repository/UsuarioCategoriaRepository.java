package com.matchup.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.matchup.model.Usuario;
import com.matchup.model.UsuarioCategoria;


@Repository
public interface UsuarioCategoriaRepository extends JpaRepository<UsuarioCategoria, Long> {
	
	@Transactional
    void deleteByUsuarioId(Long idUsuario);
	
	 void deleteByUsuario(Usuario usuario);

}
