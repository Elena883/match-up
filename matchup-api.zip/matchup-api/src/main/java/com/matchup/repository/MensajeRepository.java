package com.matchup.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.matchup.model.Mensaje;

@Repository
public interface MensajeRepository extends JpaRepository<Mensaje, Long> {

	
	
	List<Mensaje> findByGrupoIdOrderByIdAsc(Long idGrupo);


	List<Mensaje> findByGrupoIdAndIdGreaterThanOrderByIdAsc(Long idGrupo, Long ultimoId);

	Mensaje findTopByGrupoIdOrderByFechaEnvioDesc(Long idGrupo);
	
	List<Mensaje> findByUsuarioId(Long idUsuario);
	
	
	 void deleteByGrupoId(Long idGrupo);

}