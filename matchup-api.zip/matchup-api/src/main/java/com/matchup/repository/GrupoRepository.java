package com.matchup.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.matchup.model.Grupo;

@Repository
public interface GrupoRepository extends JpaRepository<Grupo, Long> {

	Optional<Grupo> findByPlanId(Long idPlan);

	List<Grupo> findAllByPlanId(Long idPlan);

	List<Grupo> findByNombreContainingIgnoreCase(String nombre);

	List<Grupo> findByCategoriaNombreIgnoreCase(String categoria);

	List<Grupo> findByNombreContainingIgnoreCaseAndCategoriaNombreIgnoreCase(String nombre, String categoria);
}
