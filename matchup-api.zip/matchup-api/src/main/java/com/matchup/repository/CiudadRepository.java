package com.matchup.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.matchup.model.Ciudad;

@Repository
public interface CiudadRepository extends JpaRepository<Ciudad, Long> {
	
	List<Ciudad> findAllByOrderByNombreAsc();
	
	 List<Ciudad> findByPaisId(Long paisId);

}
