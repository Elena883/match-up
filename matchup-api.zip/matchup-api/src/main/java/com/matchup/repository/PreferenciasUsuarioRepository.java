package com.matchup.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.matchup.model.PreferenciasUsuario;

@Repository
public interface PreferenciasUsuarioRepository extends JpaRepository<PreferenciasUsuario, Long> {

	@Transactional
	void deleteByUsuarioId(Long idUsuario);
	
	
}
