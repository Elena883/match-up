package com.matchup.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.matchup.model.Plan;

@Repository
public interface PlanRepository extends JpaRepository<Plan, Long> {

	List<Plan> findByCreadorId(Long idUsuario);

	@Query("""
			SELECT p FROM Plan p
			WHERE
			(
			    :busqueda IS NULL

			    OR LOWER(p.titulo) LIKE LOWER(CONCAT('%', :busqueda, '%'))

			    OR LOWER(p.descripcion) LIKE LOWER(CONCAT('%', :busqueda, '%'))

			    OR LOWER(p.ubicacion.ciudad.nombre) LIKE LOWER(CONCAT('%', :busqueda, '%'))

			    OR LOWER(p.ubicacion.pais.nombre) LIKE LOWER(CONCAT('%', :busqueda, '%'))

			    OR LOWER(p.categoria.nombre) LIKE LOWER(CONCAT('%', :busqueda, '%'))
			)

			AND
			(
			    :categoria IS NULL
			    OR LOWER(p.categoria.nombre) = LOWER(:categoria)
			)
			""")
	List<Plan> filtrarPlanes(@Param("busqueda") String busqueda, @Param("categoria") String categoria);

	List<Plan> findByGrupoId(Long idGrupo);

}
