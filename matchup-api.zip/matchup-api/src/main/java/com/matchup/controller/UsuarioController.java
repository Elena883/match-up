package com.matchup.controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.DeleteMapping;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matchup.dto.ActualizarAjustesDTO;
import com.matchup.dto.ActualizarPerfilDTO;
import com.matchup.dto.LoginDTO;
import com.matchup.dto.RegistroCompletoDTO;
import com.matchup.dto.UsuarioAjustesDTO;
import com.matchup.dto.UsuarioRecomendadoDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Ciudad;
import com.matchup.model.Usuario;
import com.matchup.model.UsuarioCategoria;
import com.matchup.repository.CategoriaRepository;
import com.matchup.repository.CiudadRepository;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UsuarioCategoriaRepository;
import com.matchup.repository.UsuarioGrupoRepository;
import com.matchup.repository.UsuarioRepository;
import com.matchup.service.UsuarioService;
import com.matchup.model.PreferenciasUsuario;
import com.matchup.repository.PreferenciasUsuarioRepository;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

	@Autowired
	private UsuarioRepository usuarioRepository;
	
	
	@Autowired
	private UsuarioGrupoRepository usuarioGrupoRepository;

	@Autowired
	private UsuarioService usuarioService;

	@Autowired
	private CategoriaRepository categoriaRepository;

	@Autowired
	private CiudadRepository ciudadRepository;

	@Autowired
	private UsuarioCategoriaRepository usuarioCategoriaRepository;

	@Autowired
	private PreferenciasUsuarioRepository preferenciasUsuarioRepository;

	@GetMapping("/email/{email}")
	public boolean existeEmail(@PathVariable String email) {

		return usuarioRepository.existsByEmail(email);
	}

	@GetMapping("/actividad/{idUsuario}")
	public ResponseEntity<?> obtenerActividad(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(usuarioService.obtenerActividadUsuario(idUsuario));
	}

	@GetMapping("/{id}/planes")
	public ResponseEntity<?> obtenerPlanesUsuario(@PathVariable Long id) {

		return ResponseEntity.ok(usuarioService.obtenerPlanesUsuario(id));
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> obtenerUsuario(@PathVariable Long id) {

		Usuario usuario = usuarioService.obtenerUsuarioPorId(id);

		return ResponseEntity.ok(usuario);
	}

	@GetMapping("/perfil-recomendado/{idUsuario}")
	public ResponseEntity<?> obtenerPerfilRecomendado(@PathVariable Long idUsuario) {

		UsuarioRecomendadoDTO usuario = usuarioService.obtenerPerfilRecomendado(idUsuario);

		return ResponseEntity.ok(usuario);
	}

	@GetMapping("/recomendados/{idUsuario}")
	public ResponseEntity<?> obtenerUsuariosRecomendados(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(usuarioService.obtenerUsuariosRecomendados(idUsuario));
	}

	@PutMapping(value = "/{id}/perfil", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Usuario> actualizarPerfil(

			@PathVariable Long id,

			@RequestParam String nombreUsuario, @RequestParam String nombre, @RequestParam String fechaNacimiento,
			@RequestParam String bio, @RequestParam Long idCiudad,

			@RequestParam String disponibilidad, @RequestParam Integer distancia, @RequestParam String ritmo,
			@RequestParam String tipo_plan,

			@RequestParam String categoriasIds,

			@RequestParam(required = false) MultipartFile fotoPerfil

	) {

		Usuario usuario = null;
		try {
			usuario = usuarioService.actualizarPerfil(id, nombreUsuario, nombre, fechaNacimiento, bio, idCiudad,
					disponibilidad, distancia, ritmo, tipo_plan, categoriasIds, fotoPerfil);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ResponseEntity.ok(usuario);
	}

	@DeleteMapping("/{idUsuario}")
	public ResponseEntity<?> eliminarUsuario(@PathVariable Long idUsuario) {

		try {

			usuarioService.eliminarUsuario(idUsuario);

			return ResponseEntity.ok("Usuario eliminado correctamente");

		} catch (Exception e) {

			e.printStackTrace();

			return ResponseEntity.badRequest().body("Error al eliminar usuario");
		}
	}

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) {

		Usuario usuario = usuarioRepository.findByEmailOrNombreUsuario(loginDTO.getLogin(), loginDTO.getLogin())
				.orElse(null);

		if (usuario == null) {
			return ResponseEntity.badRequest().body("Usuario no encontrado");
		}

		if (!usuario.getContrasenya().equals(loginDTO.getContrasenya())) {
			return ResponseEntity.badRequest().body("Contraseña incorrecta");
		}

		return ResponseEntity.ok(usuario);
	}

	@PutMapping("/{id}/ajustes")
	public ResponseEntity<?> actualizarAjustes(@PathVariable Long id, @RequestBody UsuarioAjustesDTO dto) {

		Usuario usuario = usuarioRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));


		if (dto.getEmail() != null && !dto.getEmail().isBlank()) {

			usuario.setEmail(dto.getEmail());
		}

		if (dto.getNombreUsuario() != null && !dto.getNombreUsuario().isBlank()) {

			usuario.setNombreUsuario(dto.getNombreUsuario());
		}

		

		if (dto.getPasswordNueva() != null && !dto.getPasswordNueva().isBlank()) {

			if (!usuario.getPassword().equals(dto.getPasswordActual())) {

				return ResponseEntity.badRequest().body("La contraseña actual es incorrecta");
			}

			usuario.setPassword(dto.getPasswordNueva());
		}

	

		PreferenciasUsuario preferencias = usuario.getPreferencias();

		preferencias.setNotifMensajes(dto.getNotifMensajes());

		preferencias.setNotifPlanesCerca(dto.getNotifPlanesCerca());

		preferencias.setNotifParticipantes(dto.getNotifParticipantes());

		preferencias.setMostrarCiudad(dto.getMostrarCiudad());

		preferencias.setMostrarPlanes(dto.getMostrarPlanes());

		preferencias.setRecomendacionesPersonalizadas(dto.getRecomendacionesPersonalizadas());

		

		usuarioRepository.save(usuario);

		return ResponseEntity.ok(usuario);
	}

	@PostMapping("/registro-completo")
	public ResponseEntity<?> registroCompleto(@RequestPart("usuario") String usuarioJson,
			@RequestPart(value = "foto", required = false) MultipartFile foto) {

		try {

			ObjectMapper mapper = new ObjectMapper();
			RegistroCompletoDTO usuarioDTO = mapper.readValue(usuarioJson, RegistroCompletoDTO.class);



			Usuario usuario = new Usuario();

			Ciudad ciudad = ciudadRepository.findById(usuarioDTO.getIdCiudad())
					.orElseThrow(() -> new RuntimeException("Ciudad no encontrada"));

			usuario.setNombreUsuario(usuarioDTO.getNombreUsuario());
			usuario.setNombre(usuarioDTO.getNombre());
			usuario.setEmail(usuarioDTO.getEmail());
			usuario.setContrasenya(usuarioDTO.getContrasenya());
			usuario.setFechaNacimiento(LocalDate.parse(usuarioDTO.getFechaNacimiento()));
			usuario.setBio(usuarioDTO.getBio());
			usuario.setCiudad(ciudad);
			usuario.setGenero(usuarioDTO.getGenero());
			usuario.setFechaRegistro(LocalDateTime.now());
			usuario.setActivo(true);

			System.out.println("FOTO -> " + foto);
			if (foto != null) {
				System.out.println("NOMBRE FOTO -> " + foto.getOriginalFilename());
			} else {
				System.out.println("FOTO ES NULL");
			}
			if (foto != null && !foto.isEmpty()) {

				String rutaCarpeta = "C:/matchup/fotos_perfil";

				File carpeta = new File(rutaCarpeta);
				if (!carpeta.exists()) {
					carpeta.mkdirs();
				}

				String nombreArchivo = System.currentTimeMillis() + "_" + foto.getOriginalFilename();

				File archivoDestino = new File(rutaCarpeta + "/" + nombreArchivo);
				foto.transferTo(archivoDestino);

				usuario.setFotoPerfil(nombreArchivo);
			}

			
			Usuario usuarioGuardado = usuarioRepository.save(usuario);

		

			if (usuarioDTO.getIntereses() != null && !usuarioDTO.getIntereses().isEmpty()) {

				for (String nombreCategoria : usuarioDTO.getIntereses()) {

					Categoria categoria = categoriaRepository.findByNombre(nombreCategoria).orElse(null);

					if (categoria != null) {

						UsuarioCategoria usuarioCategoria = new UsuarioCategoria();

						usuarioCategoria.setUsuario(usuarioGuardado);
						usuarioCategoria.setCategoria(categoria);

						usuarioCategoriaRepository.save(usuarioCategoria);
					}
				}
			}

			
			PreferenciasUsuario preferencias = new PreferenciasUsuario();

			preferencias.setTipo_plan(usuarioDTO.getTipoPlan());
			preferencias.setDistancia(usuarioDTO.getDistancia());
			preferencias.setDisponibilidad(usuarioDTO.getDisponibilidad());
			preferencias.setRitmo(usuarioDTO.getRitmo());
		
			preferencias.setNotifMensajes(usuarioDTO.getNotifMensajes());

			preferencias.setNotifPlanesCerca(usuarioDTO.getNotifPlanesCerca());

			preferencias.setNotifParticipantes(usuarioDTO.getNotifParticipantes());

			preferencias.setMostrarCiudad(usuarioDTO.getMostrarCiudad());

			preferencias.setMostrarPlanes(usuarioDTO.getMostrarPlanes());

			preferencias.setRecomendacionesPersonalizadas(usuarioDTO.getRecomendacionesPersonalizadas());

			preferencias.setUsuario(usuarioGuardado);

			preferenciasUsuarioRepository.save(preferencias);

			return ResponseEntity.ok(usuarioGuardado);

		} catch (IOException e) {
			e.printStackTrace();
			return ResponseEntity.badRequest().body("Error al procesar el registro");
		}
	}

	@GetMapping("/{id}/grupos/count")
	public int contarGrupos(@PathVariable Long id) {

		return usuarioGrupoRepository.countByUsuarioId(id);
	}
}