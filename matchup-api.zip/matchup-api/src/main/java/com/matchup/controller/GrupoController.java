package com.matchup.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.matchup.dto.GrupoDTO;
import com.matchup.dto.MensajeDTO;
import com.matchup.dto.MensajeRequestDTO;
import com.matchup.dto.MiembroGrupoDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Grupo;
import com.matchup.repository.CategoriaRepository;
import com.matchup.service.GrupoService;

@RestController
@RequestMapping("/grupos")
@CrossOrigin(origins = "*")
public class GrupoController {

	@Autowired
	private GrupoService grupoService;

	@Autowired
	private CategoriaRepository categoriaRepository;

	@PostMapping("/crear/{idUsuario}")
	public GrupoDTO crearGrupo(

			@RequestParam("grupo") String grupoJson,

			@RequestParam Long categoriaId,

			@RequestParam(value = "foto", required = false) MultipartFile foto,

			@RequestParam(required = false) Long idPlan,

			@PathVariable Long idUsuario) {

		try {

			ObjectMapper mapper = new ObjectMapper();

			Grupo grupo = mapper.readValue(grupoJson, Grupo.class);

			return grupoService.crearGrupo(grupo, categoriaId, idUsuario, idPlan, foto);

		} catch (Exception e) {

			e.printStackTrace();

			return null;
		}
	}

	@GetMapping("/plan/{idPlan}")
	public ResponseEntity<?> obtenerGrupoPorPlan(@PathVariable Long idPlan) {

		Grupo grupo = grupoService.obtenerGrupoPorPlan(idPlan);

		if (grupo == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(grupo);
	}

	@PostMapping("/{idGrupo}/unirse/{idUsuario}")
	public String unirseGrupo(@PathVariable Long idGrupo, @PathVariable Long idUsuario) {

		return grupoService.unirseGrupo(idGrupo, idUsuario);
	}

	@GetMapping("/{idGrupo}/miembros")
	public List<MiembroGrupoDTO> obtenerMiembros(@PathVariable Long idGrupo) {

		return grupoService.obtenerMiembros(idGrupo);
	}

	@DeleteMapping("/{idGrupo}/salir/{idUsuario}")
	public String salirGrupo(@PathVariable Long idGrupo, @PathVariable Long idUsuario) {

		return grupoService.salirGrupo(idGrupo, idUsuario);
	}

	@DeleteMapping("/{idGrupo}/eliminar/{idUsuario}")
	public String eliminarGrupo(@PathVariable Long idGrupo, @PathVariable Long idUsuario) {

		return grupoService.eliminarGrupo(idGrupo, idUsuario);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> obtenerGrupoPorId(@PathVariable Long id) {

		Optional<Grupo> grupo = grupoService.obtenerPorId(id);

		if (grupo.isEmpty()) {

			return ResponseEntity.badRequest().body("Grupo no encontrado");
		}

		return ResponseEntity.ok(grupo.get());
	}

	@PutMapping("/{idGrupo}")
	public ResponseEntity<?> editarGrupo(

			@PathVariable Long idGrupo,

			@RequestParam String nombre,

			@RequestParam String descripcion,

			@RequestParam Long categoriaId,

			@RequestParam Integer num_max_miembros,

			@RequestParam(required = false) MultipartFile imagen

	) {
		try {

			Grupo grupo = grupoService.editarGrupo(idGrupo, nombre, descripcion, categoriaId, num_max_miembros, imagen);

			return ResponseEntity.ok(grupo);

		} catch (Exception e) {

			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@GetMapping("/filtrar")
	public List<Grupo> filtrarGrupos(

			@RequestParam(required = false) String busqueda,

			@RequestParam(required = false) String categoria

	) {

		if (busqueda != null && busqueda.isBlank()) {
			busqueda = null;
		}

		if (categoria != null && categoria.isBlank()) {
			categoria = null;
		}

		return grupoService.filtrarGrupos(busqueda, categoria);
	}

}