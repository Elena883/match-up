package com.matchup.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.matchup.dto.CrearPlanDTO;
import com.matchup.dto.PlanDTO;
import com.matchup.model.Categoria;
import com.matchup.model.Plan;
import com.matchup.model.Ubicacion;
import com.matchup.model.UsuarioPlan;
import com.matchup.repository.PlanRepository;
import com.matchup.repository.UsuarioPlanRepository;
import com.matchup.service.PlanService;

@RestController
@RequestMapping("/planes")
@CrossOrigin(origins = "*")
public class PlanController {

	@Autowired
	private PlanService planService;

	@Autowired
	private PlanRepository planRepository;

	@Autowired
	private UsuarioPlanRepository usuarioPlanRepository;

	@GetMapping("/creador/{id}")
	public ResponseEntity<?> obtenerPlanesCreador(@PathVariable Long id) {

		return ResponseEntity.ok(planService.obtenerPlanesCreador(id));
	}

	@GetMapping("/calendario/{idUsuario}")
	public ResponseEntity<?> obtenerPlanesCalendario(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(usuarioPlanRepository.obtenerPlanesUsuario(idUsuario));
	}

	@GetMapping("/recomendados/{idUsuario}")
	public ResponseEntity<?> obtenerPlanesRecomendados(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(planService.obtenerPlanesRecomendados(idUsuario));
	}

	@GetMapping("/recomendacion-dia/{idUsuario}")
	public PlanDTO obtenerRecomendacionDia(@PathVariable Long idUsuario) {

		return planService.obtenerRecomendacionDia(idUsuario);
	}

	@GetMapping("/popular")
	public PlanDTO obtenerPlanPopular() {

		return planService.obtenerPlanPopular();
	}

	@GetMapping("/filtrar")
	public List<Plan> filtrarPlanes(@RequestParam(required = false) String busqueda,
			@RequestParam(required = false) String categoria) {
		if (busqueda != null && busqueda.isBlank()) {
			busqueda = null;
		}
		if (categoria != null && categoria.isBlank()) {
			categoria = null;
		}

		return planService.filtrarPlanes(busqueda, categoria);
	}

	@GetMapping("/activos/{idUsuario}")
	public ResponseEntity<?> obtenerPlanesActivos(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(planService.obtenerPlanesActivos(idUsuario));
	}

	@GetMapping("/historial/{idUsuario}")
	public ResponseEntity<?> obtenerHistorial(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(planService.obtenerHistorial(idUsuario));
	}

	@GetMapping("/ultimo/{idUsuario}")
	public ResponseEntity<?> obtenerUltimoPlan(@PathVariable Long idUsuario) {

		List<UsuarioPlan> lista = usuarioPlanRepository.obtenerPlanesUsuario(idUsuario);

		if (lista.isEmpty()) {
			return ResponseEntity.ok(null);
		}

		return ResponseEntity.ok(lista.get(0).getPlan());
	}

	@PutMapping("/{id}")
	public ResponseEntity<?> editarPlan(

			@PathVariable Long id,

			@RequestParam String titulo,

			@RequestParam String descripcion,

			@RequestParam Long idPais, @RequestParam Long idCiudad, @RequestParam(required = false) String direccion,

			@RequestParam Long idCategoria,

			@RequestParam Integer num_max_participantes,

			@RequestParam String fecha_plan,

			@RequestParam(required = false) MultipartFile imagen

	) {

		try { 

			Plan planActualizado = planService.editarPlan(id, titulo, descripcion, idPais,
		            idCiudad,
		            direccion, idCategoria,
					num_max_participantes, fecha_plan, imagen);

			return ResponseEntity.ok(planActualizado);

		} catch (Exception e) {

			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@DeleteMapping("/{idPlan}")
	public ResponseEntity<?> eliminarPlan(@PathVariable Long idPlan) {

		try {

			planService.eliminarPlanPorId(idPlan);

			return ResponseEntity.ok("Plan eliminado");

		} catch (Exception e) {

			return ResponseEntity.badRequest().body("Error al eliminar el plan");
		}
	}

	@GetMapping
	public ResponseEntity<?> obtenerPlanes() {

		return ResponseEntity.ok(planRepository.findAll());
	}

	@GetMapping("/{idPlan}")
	public ResponseEntity<?> obtenerPlanPorId(@PathVariable Long idPlan) {

		Plan plan = planService.obtenerPlanPorId(idPlan);

		if (plan == null) {
			return ResponseEntity.badRequest().body("Plan no encontrado");
		}

		return ResponseEntity.ok(plan);
	}

	@GetMapping("/usuario/{idUsuario}")
	public ResponseEntity<?> obtenerPlanesPorUsuario(@PathVariable Long idUsuario) {

		return ResponseEntity.ok(planService.obtenerPlanesPorUsuario(idUsuario));
	}

	@PostMapping("/crear/{idUsuario}")
	public ResponseEntity<?> crearPlan(@PathVariable Long idUsuario, @RequestPart("plan") String planJson,
			@RequestPart(value = "foto", required = false) MultipartFile foto) {

		try {

			ObjectMapper mapper = new ObjectMapper();
			CrearPlanDTO request = mapper.readValue(planJson, CrearPlanDTO.class);

			if (foto != null && !foto.isEmpty()) {

				String rutaCarpeta = "C:/matchup/fotos_plan";

				File carpeta = new File(rutaCarpeta);
				if (!carpeta.exists()) {
					carpeta.mkdirs();
				}

				String nombreArchivo = System.currentTimeMillis() + "_" + foto.getOriginalFilename();

				File archivoDestino = new File(rutaCarpeta + "/" + nombreArchivo);

				foto.transferTo(archivoDestino);

				request.setImagen(nombreArchivo);
			}

			Plan nuevoPlan = planService.crearPlan(request, idUsuario);

			return ResponseEntity.ok(nuevoPlan);

		} catch (Exception e) {

			e.printStackTrace();

			return ResponseEntity.badRequest().body("Error: " + e.getMessage());
		}
	}

	@GetMapping("/grupo/{idGrupo}")
	public List<Plan> obtenerPlanesGrupo(@PathVariable Long idGrupo) {

		return planService.obtenerPlanesGrupo(idGrupo);
	}
}