package com.matchup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.matchup.service.UsuarioPlanService;

@RestController
@RequestMapping("/usuario-plan")
@CrossOrigin(origins = "*")
public class UsuarioPlanController {

	@Autowired
	private UsuarioPlanService usuarioPlanService;
	

	@GetMapping("/existe/{idUsuario}/{idPlan}")
	public boolean existeRelacion(@PathVariable Long idUsuario, @PathVariable Long idPlan) {
		return usuarioPlanService.existeRelacion(idUsuario, idPlan);
	}

	@GetMapping("/plan/{idPlan}")
	public ResponseEntity<?> obtenerParticipantes(@PathVariable Long idPlan) {

		return ResponseEntity.ok(usuarioPlanService.obtenerParticipantesPorPlan(idPlan));
	}
	

	

	@PostMapping("/unirse/{idUsuario}/{idPlan}")
	public ResponseEntity<?> unirseAPlan(@PathVariable Long idUsuario, @PathVariable Long idPlan) {

		try {
			usuarioPlanService.unirseAPlan(idUsuario, idPlan);
			return ResponseEntity.ok("Usuario unido correctamente");

		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@DeleteMapping("/salir/{idUsuario}/{idPlan}")
	public ResponseEntity<?> salirDelPlan(@PathVariable Long idUsuario, @PathVariable Long idPlan) {

		try {

			usuarioPlanService.salirDelPlan(idUsuario, idPlan);

			return ResponseEntity.ok("Has salido del plan");

		} catch (Exception e) {

			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}
}