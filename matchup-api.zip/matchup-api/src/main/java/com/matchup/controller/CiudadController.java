package com.matchup.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.matchup.model.Ciudad;
import com.matchup.service.CiudadService;

@RestController
@RequestMapping("/ciudades")
@CrossOrigin("*")
public class CiudadController {

	@Autowired
	private CiudadService ciudadService;

	@GetMapping
	public List<Ciudad> obtenerCiudades() {

		return ciudadService.obtenerTodas();
	}

	public CiudadController(CiudadService ciudadService) {
		this.ciudadService = ciudadService;
	}

	@GetMapping("/pais/{paisId}")
	public List<Ciudad> obtenerCiudadesPorPais(@PathVariable Long paisId) {
		return ciudadService.obtenerPorPais(paisId);
	}

}