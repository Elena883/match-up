package com.matchup.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.matchup.model.Mensaje;
import com.matchup.model.UsuarioGrupo;
import com.matchup.repository.UsuarioGrupoRepository;
import com.matchup.service.MensajeService;

@RestController
@RequestMapping("/mensajes")
@CrossOrigin(origins = "*")
public class MensajeController {

	@Autowired
	private MensajeService mensajeService;

	@Autowired
	private UsuarioGrupoRepository usuarioGrupoRepository;

	@PostMapping
	public Mensaje enviarMensaje(@RequestBody Map<String, String> body) {

		Long idUsuario = Long.parseLong(body.get("idUsuario"));

		Long idGrupo = Long.parseLong(body.get("idGrupo"));

		String contenido = body.get("contenido");

		return mensajeService.enviarMensaje(idUsuario, idGrupo, contenido);
	}

	@GetMapping("/grupo/{idGrupo}/acceso/{idUsuario}")
	public boolean tieneAccesoChat(@PathVariable Long idGrupo, @PathVariable Long idUsuario) {

		return mensajeService.tieneAccesoChat(idGrupo, idUsuario);
	}


	@GetMapping("/grupo/{idGrupo}")
	public List<Mensaje> obtenerMensajesGrupo(@PathVariable Long idGrupo) {

		return mensajeService.obtenerMensajesGrupo(idGrupo);
	}

	@GetMapping("/grupo/{idGrupo}/ultimo")
	public Mensaje obtenerUltimoMensaje(@PathVariable Long idGrupo) {

		return mensajeService.obtenerUltimoMensaje(idGrupo);
	}

	@GetMapping("/grupo/{idGrupo}/nuevos")
	public List<Mensaje> obtenerMensajesNuevos(

			@PathVariable Long idGrupo,

			@RequestParam Long ultimoId) {

		return mensajeService.obtenerMensajesNuevos(idGrupo, ultimoId);
	}


	@GetMapping("/grupo/{idGrupo}/miembros")
	public long obtenerNumeroMiembros(@PathVariable Long idGrupo) {

		return usuarioGrupoRepository.countByGrupoId(idGrupo);
	}

	@GetMapping("/mis-grupos/{idUsuario}")
	public List<UsuarioGrupo> obtenerMisGrupos(@PathVariable Long idUsuario) {

		return usuarioGrupoRepository.findByUsuarioId(idUsuario);
	}
}