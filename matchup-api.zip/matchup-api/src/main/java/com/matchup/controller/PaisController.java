package com.matchup.controller;

import com.matchup.model.Pais;
import com.matchup.service.PaisService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/paises")
@CrossOrigin(origins = "*")
public class PaisController {

    private final PaisService paisService;

    public PaisController(PaisService paisService) {
        this.paisService = paisService;
    }

    @GetMapping
    public List<Pais> obtenerPaises() {
        return paisService.obtenerTodos();
    }
}