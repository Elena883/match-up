package com.matchup.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {

		registry.addResourceHandler("/fotos_perfil/**").addResourceLocations("file:///C:/matchup/fotos_perfil/");

		registry.addResourceHandler("/fotos_plan/**").addResourceLocations("file:///C:/matchup/fotos_plan/");

		registry.addResourceHandler("/fotos_grupo/**").addResourceLocations("file:///C:/matchup/fotos_grupo/");
	}

}