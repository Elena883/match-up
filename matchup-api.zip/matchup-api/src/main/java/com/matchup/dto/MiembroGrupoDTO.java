package com.matchup.dto;

public class MiembroGrupoDTO {

    private Long idUsuario;

    private String nombreUsuario;

    private String fotoPerfil;

    public MiembroGrupoDTO() {
    }

    public MiembroGrupoDTO(
            Long idUsuario,
            String nombreUsuario,
            String fotoPerfil
    ) {

        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
        this.fotoPerfil = fotoPerfil;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }
}