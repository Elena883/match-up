package com.matchup.dto;

public class ActualizarAjustesDTO {

   

    private String email;

    private String nombreUsuario;

    private String password;

  

    private Boolean notifMensajes;

    private Boolean notifPlanesCerca;

    private Boolean notifParticipantes;

    private Boolean mostrarCiudad;

    private Boolean mostrarPlanes;

    private Boolean recomendacionesPersonalizadas;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getNotifMensajes() {
		return notifMensajes;
	}

	public void setNotifMensajes(Boolean notifMensajes) {
		this.notifMensajes = notifMensajes;
	}

	public Boolean getNotifPlanesCerca() {
		return notifPlanesCerca;
	}

	public void setNotifPlanesCerca(Boolean notifPlanesCerca) {
		this.notifPlanesCerca = notifPlanesCerca;
	}

	public Boolean getNotifParticipantes() {
		return notifParticipantes;
	}

	public void setNotifParticipantes(Boolean notifParticipantes) {
		this.notifParticipantes = notifParticipantes;
	}

	public Boolean getMostrarCiudad() {
		return mostrarCiudad;
	}

	public void setMostrarCiudad(Boolean mostrarCiudad) {
		this.mostrarCiudad = mostrarCiudad;
	}

	public Boolean getMostrarPlanes() {
		return mostrarPlanes;
	}

	public void setMostrarPlanes(Boolean mostrarPlanes) {
		this.mostrarPlanes = mostrarPlanes;
	}

	public Boolean getRecomendacionesPersonalizadas() {
		return recomendacionesPersonalizadas;
	}

	public void setRecomendacionesPersonalizadas(Boolean recomendacionesPersonalizadas) {
		this.recomendacionesPersonalizadas = recomendacionesPersonalizadas;
	}


    
    
    
    
}