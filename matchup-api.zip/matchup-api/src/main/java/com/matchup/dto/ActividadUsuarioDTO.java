package com.matchup.dto;

public class ActividadUsuarioDTO {

    private int planesCreados;
    private int planesUnidos;
    private int personasConocidas;
    private String categoriaFavorita;

    public ActividadUsuarioDTO() {
    }

    public int getPlanesCreados() {
        return planesCreados;
    }

    public void setPlanesCreados(int planesCreados) {
        this.planesCreados = planesCreados;
    }

    public int getPlanesUnidos() {
        return planesUnidos;
    }

    public void setPlanesUnidos(int planesUnidos) {
        this.planesUnidos = planesUnidos;
    }

    public int getPersonasConocidas() {
        return personasConocidas;
    }

    public void setPersonasConocidas(int personasConocidas) {
        this.personasConocidas = personasConocidas;
    }

    public String getCategoriaFavorita() {
        return categoriaFavorita;
    }

    public void setCategoriaFavorita(String categoriaFavorita) {
        this.categoriaFavorita = categoriaFavorita;
    }
}