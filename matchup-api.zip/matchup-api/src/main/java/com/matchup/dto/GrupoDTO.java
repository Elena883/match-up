package com.matchup.dto;

public class GrupoDTO {

    private Long id;
    private String nombre;
    private Long categoriaId;
    private String descripcion;

    private String nombreCreador;

    private String tituloPlan;
    
    

    public GrupoDTO() {
    }

    public GrupoDTO(Long id, String nombre, String descripcion,
                    String nombreCreador, String tituloPlan) {

        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.nombreCreador = nombreCreador;
        this.tituloPlan = tituloPlan;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombreCreador() {
        return nombreCreador;
    }

    public void setNombreCreador(String nombreCreador) {
        this.nombreCreador = nombreCreador;
    }

    public String getTituloPlan() {
        return tituloPlan;
    }

    public void setTituloPlan(String tituloPlan) {
        this.tituloPlan = tituloPlan;
    }

	public Long getCategoriaId() {
		return categoriaId;
	}

	public void setCategoriaId(Long categoriaId) {
		this.categoriaId = categoriaId;
	}
    
    
}