package com.matchup.dto;

import com.matchup.model.Categoria;
import com.matchup.model.Ubicacion;

public class CrearPlanDTO {

	private String titulo;
	private String descripcion;
	private String fecha;
	private String hora;
	private Integer numMaxParticipantes;
	private Long categoriaId;
	private Long paisId;
	private Long ciudadId;
	private String direccion;
	private String duracion;
	private String privacidad;
	private String perfilBuscado;
	private String imagen;

	public CrearPlanDTO() {
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Integer getNumMaxParticipantes() {
		return numMaxParticipantes;
	}

	public void setNumMaxParticipantes(Integer numMaxParticipantes) {
		this.numMaxParticipantes = numMaxParticipantes;
	}

	public Long getCategoriaId() {
		return categoriaId;
	}

	public void setCategoriaId(Long categoriaId) {
		this.categoriaId = categoriaId;
	}

	public Long getPaisId() {
		return paisId;
	}

	public void setPaisId(Long paisId) {
		this.paisId = paisId;
	}

	public Long getCiudadId() {
		return ciudadId;
	}

	public void setCiudadId(Long ciudadId) {
		this.ciudadId = ciudadId;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getDuracion() {
		return duracion;
	}

	public void setDuracion(String duracion) {
		this.duracion = duracion;
	}

	public String getPrivacidad() {
		return privacidad;
	}

	public void setPrivacidad(String privacidad) {
		this.privacidad = privacidad;
	}

	public String getPerfilBuscado() {
		return perfilBuscado;
	}

	public void setPerfilBuscado(String perfilBuscado) {
		this.perfilBuscado = perfilBuscado;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

}
