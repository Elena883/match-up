package com.matchup.dto;

import java.time.LocalDateTime;

public class MensajeDTO {

    private String usuario;

    private String fotoPerfil;

    private String contenido;

    private LocalDateTime fecha;

    public MensajeDTO() {
    }

    public MensajeDTO(
            String usuario,
            String fotoPerfil,
            String contenido,
            LocalDateTime fecha
    ) {

        this.usuario = usuario;
        this.fotoPerfil = fotoPerfil;
        this.contenido = contenido;
        this.fecha = fecha;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }
}