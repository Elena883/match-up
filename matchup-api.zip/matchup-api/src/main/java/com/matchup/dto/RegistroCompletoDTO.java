package com.matchup.dto;

import java.util.List;

import com.matchup.model.Ciudad;

public class RegistroCompletoDTO {

	
	private String nombreUsuario;
	private String nombre;
	private String email;
	private String contrasenya;
	private String fechaNacimiento;
	private String bio;
	private String genero;
	private Long idCiudad;
	private String fotoPerfil;

	
	private List<String> intereses;


	private String tipoPlan;
	private Integer distancia;
	private String disponibilidad;
	private String ritmo;


	private Boolean notifMensajes;

	private Boolean notifPlanesCerca;

	private Boolean notifParticipantes;

	private Boolean mostrarCiudad;

	private Boolean mostrarPlanes;

	private Boolean recomendacionesPersonalizadas;

	public RegistroCompletoDTO() {
	}


	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContrasenya() {
		return contrasenya;
	}

	public void setContrasenya(String contrsenya) {
		this.contrasenya = contrsenya;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public Long getIdCiudad() {
		return idCiudad;
	}

	public void setIdCiudad(Long idCiudad) {
		this.idCiudad = idCiudad;
	}

	public List<String> getIntereses() {
		return intereses;
	}

	public void setIntereses(List<String> intereses) {
		this.intereses = intereses;
	}

	public String getTipoPlan() {
		return tipoPlan;
	}

	public void setTipoPlan(String tipoPlan) {
		this.tipoPlan = tipoPlan;
	}

	public Integer getDistancia() {
		return distancia;
	}

	public void setDistancia(Integer distancia) {
		this.distancia = distancia;
	}

	public String getDisponibilidad() {
		return disponibilidad;
	}

	public void setDisponibilidad(String disponibilidad) {
		this.disponibilidad = disponibilidad;
	}

	public String getRitmo() {
		return ritmo;
	}

	public void setRitmo(String ritmo) {
		this.ritmo = ritmo;
	}

	public Boolean getNotifMensajes() {
		return notifMensajes;
	}

	public void setNotifMensajes(Boolean notifMensajes) {
		this.notifMensajes = notifMensajes;
	}

	public Boolean getNotifPlanesCerca() {
		return notifPlanesCerca;
	}

	public void setNotifPlanesCerca(Boolean notifPlanesCerca) {
		this.notifPlanesCerca = notifPlanesCerca;
	}

	public Boolean getNotifParticipantes() {
		return notifParticipantes;
	}

	public void setNotifParticipantes(Boolean notifParticipantes) {
		this.notifParticipantes = notifParticipantes;
	}

	public Boolean getMostrarCiudad() {
		return mostrarCiudad;
	}

	public void setMostrarCiudad(Boolean mostrarCiudad) {
		this.mostrarCiudad = mostrarCiudad;
	}

	public Boolean getMostrarPlanes() {
		return mostrarPlanes;
	}

	public void setMostrarPlanes(Boolean mostrarPlanes) {
		this.mostrarPlanes = mostrarPlanes;
	}

	public Boolean getRecomendacionesPersonalizadas() {
		return recomendacionesPersonalizadas;
	}

	public void setRecomendacionesPersonalizadas(Boolean recomendacionesPersonalizadas) {
		this.recomendacionesPersonalizadas = recomendacionesPersonalizadas;
	}

	public String getFotoPerfil() {
		return fotoPerfil;
	}

	public void setFotoPerfil(String fotoPerfil) {
		this.fotoPerfil = fotoPerfil;
	}

}