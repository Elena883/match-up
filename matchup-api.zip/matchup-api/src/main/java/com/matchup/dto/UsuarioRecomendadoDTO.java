package com.matchup.dto;

import java.util.List;

public class UsuarioRecomendadoDTO {

    private Long id;
    private String nombre;
    private Integer edad;
    private String bio;
    private String fotoPerfil;

    private List<String> intereses;

    private Integer coincidencias;

    public UsuarioRecomendadoDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public List<String> getIntereses() {
        return intereses;
    }

    public void setIntereses(List<String> intereses) {
        this.intereses = intereses;
    }

    public Integer getCoincidencias() {
        return coincidencias;
    }

    public void setCoincidencias(Integer coincidencias) {
        this.coincidencias = coincidencias;
    }
}