package com.matchup.dto;

public class MensajeRequestDTO {

    private String contenido;

    public MensajeRequestDTO() {
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
}