package com.matchup.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuario_categoria")
public class UsuarioCategoria {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_usuario_categoria;

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name="id_usuario")
	private Usuario usuario;

	@ManyToOne
	@JoinColumn(name = "id_categoria")
	private Categoria categoria;

	public UsuarioCategoria() {
		// TODO Auto-generated constructor stub
	}

	public Long getId_usuario_categoria() {
		return id_usuario_categoria;
	}

	public void setId_usuario_categoria(Long id_usuario_categoria) {
		this.id_usuario_categoria = id_usuario_categoria;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

}