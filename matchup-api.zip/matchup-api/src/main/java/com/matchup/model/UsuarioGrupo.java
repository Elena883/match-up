package com.matchup.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuario_grupo")
public class UsuarioGrupo {

	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id_usuario_grupo;

	    @ManyToOne
	    @JoinColumn(name = "id_usuario")
	    private Usuario usuario;

	    @ManyToOne
	    @JoinColumn(name = "id_grupo")
	    private Grupo grupo;

	    private String rol;
	    private LocalDateTime fecha_union;

	    public UsuarioGrupo() {
			// TODO Auto-generated constructor stub
		}

		public Long getId_usuario_grupo() {
			return id_usuario_grupo;
		}

		public void setId_usuario_grupo(Long id_usuario_grupo) {
			this.id_usuario_grupo = id_usuario_grupo;
		}

		public Usuario getUsuario() {
			return usuario;
		}

		public void setUsuario(Usuario usuario) {
			this.usuario = usuario;
		}

		public Grupo getGrupo() {
			return grupo;
		}

		public void setGrupo(Grupo grupo) {
			this.grupo = grupo;
		}

		public String getRol() {
			return rol;
		}

		public void setRol(String rol) {
			this.rol = rol;
		}

		public LocalDateTime getFecha_union() {
			return fecha_union;
		}

		public void setFecha_union(LocalDateTime fecha_union) {
			this.fecha_union = fecha_union;
		}
	    
	    

}
