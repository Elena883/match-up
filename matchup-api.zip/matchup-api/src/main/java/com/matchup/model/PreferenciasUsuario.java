package com.matchup.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "preferencias_usuario")
public class PreferenciasUsuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_preferencia;

	private String tipo_plan;
	private Integer distancia;
	private String disponibilidad;
	private String ritmo;

	private Boolean notifMensajes = true;

	private Boolean notifPlanesCerca = true;

	private Boolean notifParticipantes = true;


	private Boolean mostrarCiudad = true;

	private Boolean mostrarPlanes = true;

	private Boolean recomendacionesPersonalizadas = true;

	@JsonIgnore
	@OneToOne
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;

	public PreferenciasUsuario() {
		// TODO Auto-generated constructor stub
	}

	public Long getId_preferencia() {
		return id_preferencia;
	}

	public void setId_preferencia(Long id_preferencia) {
		this.id_preferencia = id_preferencia;
	}

	public String getTipo_plan() {
		return tipo_plan;
	}

	public void setTipo_plan(String tipo_plan) {
		this.tipo_plan = tipo_plan;
	}

	public Integer getDistancia() {
		return distancia;
	}

	public void setDistancia(Integer distancia) {
		this.distancia = distancia;
	}

	public String getDisponibilidad() {
		return disponibilidad;
	}

	public void setDisponibilidad(String disponibilidad) {
		this.disponibilidad = disponibilidad;
	}

	public String getRitmo() {
		return ritmo;
	}

	public void setRitmo(String ritmo) {
		this.ritmo = ritmo;
	}


	public Boolean getNotifMensajes() {
		return notifMensajes;
	}

	public void setNotifMensajes(Boolean notifMensajes) {
		this.notifMensajes = notifMensajes;
	}

	public Boolean getNotifPlanesCerca() {
		return notifPlanesCerca;
	}

	public void setNotifPlanesCerca(Boolean notifPlanesCerca) {
		this.notifPlanesCerca = notifPlanesCerca;
	}

	public Boolean getNotifParticipantes() {
		return notifParticipantes;
	}

	public void setNotifParticipantes(Boolean notifParticipantes) {
		this.notifParticipantes = notifParticipantes;
	}

	public Boolean getMostrarCiudad() {
		return mostrarCiudad;
	}

	public void setMostrarCiudad(Boolean mostrarCiudad) {
		this.mostrarCiudad = mostrarCiudad;
	}

	public Boolean getMostrarPlanes() {
		return mostrarPlanes;
	}

	public void setMostrarPlanes(Boolean mostrarPlanes) {
		this.mostrarPlanes = mostrarPlanes;
	}

	public Boolean getRecomendacionesPersonalizadas() {
		return recomendacionesPersonalizadas;
	}

	public void setRecomendacionesPersonalizadas(Boolean recomendacionesPersonalizadas) {
		this.recomendacionesPersonalizadas = recomendacionesPersonalizadas;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
}