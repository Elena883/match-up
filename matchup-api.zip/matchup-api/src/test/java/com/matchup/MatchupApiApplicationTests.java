package com.matchup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchupApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
